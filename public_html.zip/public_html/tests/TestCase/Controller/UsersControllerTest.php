<?php
namespace App\Test\TestCase\Controller;

use App\Controller\UsersController;
use Cake\TestSuite\IntegrationTestCase;

/**
 * App\Controller\UsersController Test Case
 */
class UsersControllerTest extends IntegrationTestCase
{

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'app.users',
        'app.candidatures'
    ];

    /**
     * Test index method
     *
     * @return void
     */
    public function testIndex()
    {
       $this->get('/users?page=1');

        // Check for a 2xx response code
        $this->assertResponseOk();

        // Assert partial response content
        $this->assertResponseContains('Admin');
    }
    }

    /**
     * Test view method
     *
     * @return void
     */
    public function testView()
    {
                $this->get('/users/view/3');

        // Check for a 2xx response code
        $this->assertResponseOk();

        // Assert partial response content
        $this->assertResponseContains('Etud');
    }

    /**
     * Test add method
     *
     * @return void
     */
    public function testAdd()
    {
          $this->get('/users/add');

        // Check for a 2xx response code
        $this->assertResponseOk();

        $data = [
            'id' => 15,
            'last_name' => 'Justin',
            'first_name' => 'Michel',
            'email' => 'michel@michel.com',
            'password' => 'michel',
            'program' => 'Programmation',
            'age' => 1,
            'slug' => 'mic',
            'created' => time(),
            'modified' => time(),
            'role' => 'Etudiant'
        ];
        $this->post('/users/add', $data);

        // Check for a 2xx response code
        $this->assertResponseSuccess();

        // Assert view variables
        $users = TableRegistry::get('Users');
        $query = $users->find()->where(['first_name' => $data['first_name']]);
        $this->assertEquals(1, $query->count());
    }

    /**
     * Test edit method
     *
     * @return void
     */
    public function testEdit()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test delete method
     *
     * @return void
     */
    public function testDelete()
    {
              $this->delete('/users/delete/3');

        // Check for a 2xx/3xx response code
        $this->assertResponseSuccess();

        $users = TableRegistry::get('Users');
        $data = $users->find()->where(['id' => 3]);
        $this->assertEquals(0, $data->count());
    }
     public function testLoginOk()
    {
        $this->enableCsrfToken();
        $this->enableSecurityToken();

        $this->post('/users/login', [
            'last_name' => 'Roy',
            'first_name' => 'Luc',
            'email' => 'gmail@gmail.com',
            'password' => 'Admin',
            'program' => 'Informatique',
            'age' => '22',
            'slug' => 'Luc'
        ]);

        $expected = [
            'id' => 1,
            'last_name' => 'Roy'
        ];
        $this->assertSession($expected, 'Auth.User');

        $expected = [
            'controller' => 'Dashboard',
            'action' => 'index'
        ];
        $this->assertRedirect($expected);
    }

    public function testLoginFailure()
    {
        $this->enableCsrfToken();
        $this->enableSecurityToken();

        $this->post('/users/login', [
            'username' => 'wrong-username',
            'password' => 'wrong-password'
        ]);

        $this->assertNull($this->_requestSession->read('Auth.User'));

        $this->assertNoRedirect();

        $expected = __d('cockpit', 'Your username or password is incorrect');
        $this->assertResponseContains($expected);
    }
}

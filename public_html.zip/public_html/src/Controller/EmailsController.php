<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\I18n\Date;
use Cake\I18n\Time;
use Cake\Mailer\Email;

class EmailsController extends AppController
{


    public function index()
    {
        $user = $this->Auth->user("role");

        if ($user == "admin") {
            $email1 = 'michelschreyer18@gmail.com';
            $email = new Email('default');
            $email->setTo($email1)->setSubject('Info pour milieux de stages')->send( "Merci de mettre a jour les informations pour les milieux de stage");

        }else if ($user != "admin") {


            $email1 = 'michelschreyer18@gmail.com';
            $email2 = 'progphp123@gmail.com';
            $email3 = 'bibliofun123@gmail.com';


            $email = new Email('default');
            $email->setTo($email1)->setSubject('Info pour milieux de stage')->send('Merci de mettre a jour les informations sur le site');
            $email->setTo($email2)->setSubject('Info pour milieux de stage')->send('Merci de mettre a jour les informations sur le site');
            $email->setTo($email3)->setSubject('Info pour milieux de stage')->send('Merci de mettre a jour les informations sur le site');



        }
    }


    public function rencontre(){
         $this->Flash->success('Emails envoyer avec succès');
        
        if(succes){
            $email1 = 'michelschreyer18@gmail.com';
        $email = new Email('default');
        $email->setTo($email1)->setSubject('Rencontre')->send( "Bonjours, 
        Merci d'avoir postuler pour notre offre de stage.
        Nous souhaitons vous rencontrer. Si cela vous interesse merci de repondre a ce email.");
        }
        return $this->redirect(
        ['controller' => 'candidatures', 'action' => 'index']
    );
   
            
        

        
    }

    public function postuler(){
        
        if(succes){

        $email1 = 'michelschreyer18@gmail.com';
        $email = new Email('default');
        $email->setTo($email1)->setSubject('Postuler')->send( "Bonjours, je suis interese par l'offre de stage que vous avez mise");
        }
         return $this->redirect(
        ['controller' => 'Offers', 'action' => 'index']
    );
        
    }
    
    public function infoOffre(){
        $email1 = 'michelschreyer18@gmail.com';
        $email = new Email('default');
        $email->setTo($email1)->setSubject('Nouvelle offre de stage')->send( "Bonjours, une nouvelle offre de stage a ete publier");

    }
    
  
}
?>


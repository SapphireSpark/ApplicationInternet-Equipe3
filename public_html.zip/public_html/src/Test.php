<?php

use Cake\Mailer\Email;


        $email1 = 'michelschreyer18@gmail.com';
        $email = new Email('default');
        $email->setTo($email1)->setSubject('Info pour milieux de stage')->send('Merci de mettre a jour les informations sur le site');
    
?>

